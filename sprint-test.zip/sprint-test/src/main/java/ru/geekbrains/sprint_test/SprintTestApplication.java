package ru.geekbrains.sprint_test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprintTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprintTestApplication.class, args);
	}

}
